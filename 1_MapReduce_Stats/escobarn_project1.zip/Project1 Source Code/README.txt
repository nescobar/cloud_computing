CLOUD COMPUTING - PROJECT 1 CODE - README

Files included
--------------
MapReduceStats.java: Source code for the MapReduce application that calculates maximum, minimum, average and standard deviation
build.sh: Shell script to build the JAR
clean.sh: Shell script to clean up the JAR, if exists 
mapreducestats.jar: JAR application
classes/ 
        MapReduceStats.class
        MapReduceStats$Map.class
        MapReduceStats$MultipleWritable.class
        MapReduceStats$Reduce.class
input/
        Project1_Input_Data.txt
output/
        part-r-00000
        
        
Github
------
Source can also be found on Github
https://github.com/nescobar/dsprojects/blob/master/project1/src/MapReduceStats.java

        
