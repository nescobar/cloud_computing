rm -rf classes
rm mapreducestats.jar
rm -rf output
rm $HADOOP_HOME/bin/mapreducestats.jar 

