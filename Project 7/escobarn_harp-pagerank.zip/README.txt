README
------
Nicolas Escobar (escobarn)Harsh Reddy (hagandav)

1) Source code for Harp PageRank Implementation can be found in
/simplepagerank/PageRankMapper.java

2) Output is located in /output5k/part-m-00000 file